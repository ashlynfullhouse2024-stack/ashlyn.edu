import React, { useMemo, useState } from 'react';
import { X, FileText, MessageSquare, Trash2, Download, Search } from 'lucide-react';
import { CompletedOrder, OrderStatus } from '../types';
import { formatRupiah, cleanWaPhone } from '../data/initialProducts';

const STATUSES: OrderStatus[] = ['Menunggu Konfirmasi', 'Diproses', 'Dikirim', 'Selesai', 'Dibatalkan'];

interface Props {
  isOpen: boolean;
  onClose: () => void;
  orders: CompletedOrder[];
  onChangeStatus: (orderId: string, status: OrderStatus) => void;
  onDelete: (orderId: string) => void;
  onOpenInvoice: (order: CompletedOrder) => void;
}

export const OrdersModal: React.FC<Props> = ({ isOpen, onClose, orders, onChangeStatus, onDelete, onOpenInvoice }) => {
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState<'Semua' | OrderStatus>('Semua');

  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    return orders.filter((o) =>
      (statusFilter === 'Semua' || o.status === statusFilter) &&
      (!t || o.orderId.toLowerCase().includes(t) || o.customer.name.toLowerCase().includes(t) || o.customer.phone.includes(t))
    );
  }, [orders, q, statusFilter]);

  const revenue = orders
    .filter((o) => !o.isQuestionOnly && o.status !== 'Dibatalkan')
    .reduce((s, o) => s + o.totalAmount, 0);

  if (!isOpen) return null;

  const exportCsv = () => {
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const rows = [['ID', 'Tanggal', 'Nama', 'WhatsApp', 'Jenis', 'Status', 'Item', 'Total']];
    orders.forEach((o) =>
      rows.push([
        o.orderId, o.date, o.customer.name, o.customer.phone,
        o.isQuestionOnly ? 'Pertanyaan' : 'Pesanan', o.status,
        o.items.map((i) => `${i.name} x${i.qty}`).join('; '), String(o.totalAmount)
      ])
    );
    const csv = '\uFEFF' + rows.map((r) => r.map(esc).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `pesanan-ashlyn-edu-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative z-10 bg-white w-full max-w-2xl max-h-[90vh] rounded-3xl border-2 border-[#E9899F]/30 shadow-2xl flex flex-col overflow-hidden">
        <div className="p-4 border-b border-[#E9899F]/20 flex items-start justify-between gap-2">
          <div>
            <h3 className="font-brand text-lg font-bold text-[#D9574F]">Riwayat Pesanan</h3>
            <p className="text-[11px] text-stone-500">
              {orders.length} catatan • Omzet {formatRupiah(revenue)}
            </p>
            <p className="text-[10px] text-amber-700 mt-0.5">
              Hanya mencatat pesanan yang dibuat di browser ini. Pesanan dari perangkat pelanggan tetap masuk lewat WhatsApp.
            </p>
          </div>
          <button onClick={onClose} className="cursor-pointer p-1.5 rounded-full hover:bg-stone-100" aria-label="Tutup">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3 flex flex-wrap gap-2 text-xs border-b border-stone-100">
          <div className="relative flex-1 min-w-[160px]">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-stone-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari ID, nama, atau nomor"
              className="w-full pl-8 pr-3 py-2 rounded-xl border border-stone-200 outline-none focus:border-[#E9899F]" />
          </div>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as 'Semua' | OrderStatus)}
            className="px-2 py-2 rounded-xl border border-stone-200">
            <option>Semua</option>
            {STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
          <button onClick={exportCsv} disabled={orders.length === 0}
            className="cursor-pointer px-3 py-2 rounded-xl bg-[#8FA477] text-white font-bold flex items-center gap-1.5 disabled:opacity-40">
            <Download className="w-3.5 h-3.5" /> CSV
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 custom-scrollbar">
          {shown.length === 0 && (
            <p className="text-center text-xs text-stone-500 py-10">Belum ada pesanan yang cocok.</p>
          )}
          {shown.map((o) => (
            <div key={o.orderId} className="border border-stone-200 rounded-2xl p-3 text-xs space-y-2">
              <div className="flex justify-between gap-2 flex-wrap">
                <div>
                  <span className="font-bold text-stone-800">{o.orderId}</span>
                  {o.isQuestionOnly && <span className="ml-1.5 text-[10px] bg-sky-100 text-sky-800 px-1.5 rounded-full">Pertanyaan</span>}
                  <div className="text-[11px] text-stone-500">{o.date} • {o.customer.name} • {o.customer.phone}</div>
                </div>
                <div className="font-brand font-bold text-[#D9574F]">{formatRupiah(o.totalAmount)}</div>
              </div>
              <div className="text-[11px] text-stone-600">{o.items.map((i) => `${i.name} ×${i.qty}`).join(', ')}</div>
              <div className="flex items-center gap-2 flex-wrap">
                <select value={o.status} onChange={(e) => onChangeStatus(o.orderId, e.target.value as OrderStatus)}
                  className="px-2 py-1.5 rounded-lg border border-stone-200 text-[11px]">
                  {STATUSES.map((s) => <option key={s}>{s}</option>)}
                </select>
                <button onClick={() => onOpenInvoice(o)} className="cursor-pointer px-2.5 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 flex items-center gap-1 text-[11px] font-semibold">
                  <FileText className="w-3 h-3" /> Invoice
                </button>
                <a href={`https://wa.me/${cleanWaPhone(o.customer.phone)}`} target="_blank" rel="noopener noreferrer"
                  className="px-2.5 py-1.5 rounded-lg bg-[#25D366] text-white flex items-center gap-1 text-[11px] font-semibold">
                  <MessageSquare className="w-3 h-3" /> Chat
                </a>
                <button onClick={() => window.confirm(`Hapus catatan ${o.orderId}?`) && onDelete(o.orderId)}
                  className="cursor-pointer ml-auto p-1.5 rounded-lg text-red-500 hover:bg-red-50" aria-label="Hapus">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
