# Ashlyn Edu – Web Order

Katalog & pemesanan produk edukasi (React + Vite + Tailwind). Checkout membuka WhatsApp admin dengan pesan pesanan yang sudah terisi.

## Jalankan
```
npm install
npm run dev
```

## Pengaturan penting
1. **Password admin** – `npm run hash-password -- "passwordBaru"`, salin hasilnya ke `.env.local` sebagai `VITE_ADMIN_PASSWORD_HASH`.
2. **Nomor WhatsApp & rekening** – masuk Mode Admin → *Fitur Pesan WA*, ganti data contoh dengan data asli.
3. **Deploy** – push ke `main`; workflow GitHub Pages akan build otomatis. Set variabel repo `VITE_BASE` ke `/nama-repo/` jika tidak memakai domain sendiri.

## Batasan
Aplikasi ini tanpa server: produk, pesanan, dan pengaturan tersimpan di `localStorage` browser masing-masing. Riwayat pesanan hanya mencatat pesanan dari browser tersebut; verifikasi admin hanya penghalang ringan, bukan keamanan sungguhan.
