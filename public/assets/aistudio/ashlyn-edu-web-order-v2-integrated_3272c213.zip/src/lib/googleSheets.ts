/**
 * Konfigurasi integrasi Google Sheets.
 * Isi kedua nilai berikut setelah deploy Apps Script sebagai Web App.
 */
export const GOOGLE_SHEETS_WEB_APP_URL = 'TEMPEL_WEB_APP_URL_DI_SINI';
export const GOOGLE_SHEETS_TOKEN = 'TEMPEL_TOKEN_YANG_SAMA_DENGAN_APPS_SCRIPT_DI_SINI';

export function sendOrderToGoogleSheets(message: string): void {
  if (
    !GOOGLE_SHEETS_WEB_APP_URL.startsWith('https://script.google.com/macros/s/') ||
    GOOGLE_SHEETS_TOKEN.startsWith('TEMPEL_')
  ) {
    console.warn('[Ashlyn Edu] Integrasi Google Sheets belum dikonfigurasi.');
    return;
  }

  // no-cors membuat respons tidak dapat dibaca browser, tetapi POST tetap dikirim.
  // WhatsApp dibuka terpisah agar alur checkout tidak terhambat.
  try {
    void fetch(GOOGLE_SHEETS_WEB_APP_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ token: GOOGLE_SHEETS_TOKEN, pesan: message }),
      keepalive: true
    }).catch((error) => {
      console.error('[Ashlyn Edu] Pengiriman ke Google Sheets gagal:', error);
    });
  } catch (error) {
    console.error('[Ashlyn Edu] Pengiriman ke Google Sheets gagal:', error);
  }
}
